import axios from 'axios'
import Ajv from "ajv"
const API_URL = `https://api.kraken.com/0/public/Assets`
const ajv = new Ajv()

interface SubBlock {
  aclass: string
  altname: string
  decimals: number
  display_decimals: number
}

interface Block {
  [key: string]: SubBlock
}

interface AssetsApiReponse {
  error: any[]
  result: Block
}

const schema1 = {
    type: "object",
    properties: {
      error: { type: "array" },
      result: {
        type: "object"
      }
    },
    required: ["error", "result"],
    additionalProperties: false
}

const schema2 = {
  type: "array", items: {
    type: "object",
    properties: {
    aclass: { type: "string" },
    altname: { type: "string" },
    decimals: { type: "number" },
    display_decimals: { type: "number" },
    },
  }
}


const validate1 = ajv.compile(schema1)
const validate2 = ajv.compile(schema2)

describe('Assets API', () => {
    it('make sure response has correct data schema ', async()=> {
        const resp: AssetsApiReponse = (await axios.get(API_URL)).data
        if (!validate1(resp)) {
          throw new Error(`Got the following validation errors: ${JSON.stringify(validate1.errors)}`)
        }
        const tmp: SubBlock[] = []
        for (const [key, value] of Object.entries(resp.result)) {
          tmp.push(value)
        }
        if (!validate2(tmp)) {
            throw new Error(`Got the following validation errors: ${JSON.stringify(validate2.errors)}`)
        }
    })
})