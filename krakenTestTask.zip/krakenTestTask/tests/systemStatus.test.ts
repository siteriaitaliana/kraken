import axios from 'axios'
const API_URL = 'https://api.kraken.com/0/public/SystemStatus'

describe('System status', () => {
    it('returns online', async()=> {
        const resp = await axios.get(API_URL)
        expect(resp.data.result.status).toEqual('online')
    })
})