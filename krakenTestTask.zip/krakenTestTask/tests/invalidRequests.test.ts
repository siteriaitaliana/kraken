import axios from 'axios'
import WebSocket from 'ws'

const WS_URL = 'wss://ws.kraken.com'
const INVALID_REST_URL = 'https://futures.kraken.com/derivatives/api/v3/instrument'

describe('Invalid requests', () => {
    it('REST API', async()=> {
        try{
            const resp = await axios.get(INVALID_REST_URL)
            expect(false).toBe(true)
        } catch(err){
            expect(err.response.status).toEqual(404)
            expect(err.response.statusText).toEqual('Not Found')
        }      
    })
    it('WSS', async(done)=> {
        let errorMsgPresent = false
        const wss = new WebSocket(WS_URL)

        wss.onopen = ()=>{
            console.log('websocket client connected')
            const payload = `{
                "event": "ping",
                "reqid": 'abcdefg'
              }`
            wss.send(payload)
        }
        
        wss.onmessage = (message: any)=>{
            const json = JSON.parse(message.data)
            if(json.event && json.event === 'error' && json.errorMessage && json.errorMessage === 'Malformed request'){
                errorMsgPresent = true
                wss.close()
                done()
            }
        }        
    })
})