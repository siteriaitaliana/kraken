const WS_URL = 'wss://ws.kraken.com'
import WebSocket from 'ws'

jest.setTimeout(30000)

describe('Subscribe to ws trade', () => {
    it('returns timestamps in increasing order', async(done)=> {
        let iterations = 10
        let prevTimestamp = 0
        const wss = new WebSocket(WS_URL)

        wss.onopen = ()=>{
            console.log('websocket client connected')
            const payload = `{
                "event": "subscribe",
                "pair": [
                  "XBT/USD"
                ],
                "subscription": {
                  "name": "trade"
                }
              }`
            wss.send(payload)
        }
        
        wss.onmessage = (message: any)=>{
        const json = JSON.parse(message.data)
            if(Array.isArray(json)) {
                const lastTimeStamp = parseFloat(json[1][0][2])
                expect(prevTimestamp <= lastTimeStamp).toBe(true)
                prevTimestamp = lastTimeStamp
                if(iterations === 0) {
                    wss.close()
                    done()
                }
                else {
                    iterations--
                }
            }
        }        
    })
})