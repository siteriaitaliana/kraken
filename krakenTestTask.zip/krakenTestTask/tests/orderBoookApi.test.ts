import axios from 'axios'
const PAIR = 'XXBTZUSD'
const API_URL = `https://api.kraken.com/0/public/Depth?pair=XBTUSD`

describe('Order book', () => {
    it('top ask price is greater than top bid price', async()=> {
        const resp = await axios.get(API_URL)
        expect(parseFloat(resp.data.result[PAIR].asks[0][0])).toBeGreaterThan(parseFloat(resp.data.result[PAIR].bids[0][0]))
    })
})