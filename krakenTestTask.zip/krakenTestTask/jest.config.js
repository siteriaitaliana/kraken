module.exports = {
  testEnvironment: 'node',
  clearMocks: true,
  modulePathIgnorePatterns: ['<rootDir>/dist/', '<rootDir>/node_modules/'],
  coveragePathIgnorePatterns: ['<rootDir>/dist/', '<rootDir>/node_modules/'],
  testRegex: '(/__tests__/.*|(\\.|/)(test|spec))\\.(jsx?|tsx?)$',
  moduleFileExtensions: ['js', 'json', 'node', 'ts'],
  moduleDirectories: ['node_modules'],
  verbose: true,
  setupFilesAfterEnv: ['jest-expect-message'],
  preset: 'ts-jest',
  testMatch: null,
}
